
/*  A Bison parser, made from parser.y with Bison version GNU Bison version 1.24
  */

#define YYBISON 1  /* Identify Bison output.  */

#define	TIDEN	258
#define	TNUMBER	259
#define	TCONST	260
#define	ELSE	261
#define	TIF	262
#define	TINT	263
#define	TRETURN	264
#define	TVOID	265
#define	TWHILE	266
#define	TEIF	267
#define	TFLOAT	268
#define	TCHAR	269
#define	TSTRING	270
#define	TOCTA	271
#define	THEXA	272
#define	TREAL	273
#define	TADDASSIGN	274
#define	TSUBASSIGN	275
#define	TMULASSIGN	276
#define	TDIVASSIGN	277
#define	TMODASSIGN	278
#define	TOR	279
#define	TAND	280
#define	TEQUAL	281
#define	TNOTEQU	282
#define	TGREAT	283
#define	TLESS	284
#define	TGREATE	285
#define	TLESSE	286
#define	TINC	287
#define	TDEC	288
#define	TPLUS	289
#define	TMINUS	290
#define	TMULTIPLY	291
#define	TDIVIDE	292
#define	TMOD	293
#define	TNOT	294
#define	TASSIGN	295
#define	TLPAREN	296
#define	TRPAREN	297
#define	TCOMMA	298
#define	TSEMICOLON	299
#define	TLBRACKET	300
#define	TRBRACKET	301
#define	TLBRACE	302
#define	TRBRACE	303
#define	TNEWLINE	304
#define	TERROR	305
#define	TBLANK	306
#define	TTAB	307
#define	TEOF	308
#define	LOWER_THEN_ELSE	309
#define	TELSE	310

#line 1 "parser.y"

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <malloc.h>

#include "glob.h"

int type_int = 0;
int type_void = 0;
int type_float = 0;
int type_char = 0;

void line(int);
extern printError();
extern yylex();
extern yyerror(s);

#ifndef YYLTYPE
typedef
  struct yyltype
    {
      int timestamp;
      int first_line;
      int first_column;
      int last_line;
      int last_column;
      char *text;
   }
  yyltype;

#define YYLTYPE yyltype
#endif

#ifndef YYSTYPE
#define YYSTYPE int
#endif
#include <stdio.h>

#ifndef __cplusplus
#ifndef __STDC__
#define const
#endif
#endif



#define	YYFINAL		176
#define	YYFLAG		-32768
#define	YYNTBASE	56

#define YYTRANSLATE(x) ((unsigned)(x) <= 310 ? yytranslate[x] : 102)

static const char yytranslate[] = {     0,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     1,     2,     3,     4,     5,
     6,     7,     8,     9,    10,    11,    12,    13,    14,    15,
    16,    17,    18,    19,    20,    21,    22,    23,    24,    25,
    26,    27,    28,    29,    30,    31,    32,    33,    34,    35,
    36,    37,    38,    39,    40,    41,    42,    43,    44,    45,
    46,    47,    48,    49,    50,    51,    52,    53,    54,    55
};

#if YYDEBUG != 0
static const short yyprhs[] = {     0,
     0,     2,     4,     7,     9,    11,    14,    17,    20,    23,
    26,    30,    33,    35,    37,    40,    42,    44,    46,    48,
    50,    52,    54,    56,    60,    64,    66,    67,    69,    73,
    76,    79,    83,    87,    90,    92,    93,    95,    98,   102,
   106,   108,   112,   114,   118,   122,   124,   129,   134,   136,
   137,   139,   140,   142,   145,   148,   150,   152,   154,   156,
   158,   161,   164,   166,   167,   173,   181,   187,   191,   193,
   196,   199,   202,   205,   208,   212,   216,   218,   222,   226,
   230,   234,   238,   242,   246,   248,   252,   254,   258,   260,
   264,   268,   270,   274,   278,   282,   286,   288,   292,   296,
   298,   302,   306,   310,   312,   315,   318,   321,   324,   326,
   331,   336,   339,   342,   347,   349,   350,   352,   354,   358,
   360,   362
};

static const short yyrhs[] = {    57,
     0,    58,     0,    57,    58,     0,    59,     0,    75,     0,
     3,    44,     0,     3,     1,     0,    60,    71,     0,    60,
    44,     0,    60,     1,     0,    61,    66,    67,     0,    61,
    67,     0,    62,     0,    63,     0,    62,    63,     0,    64,
     0,    65,     0,     5,     0,     8,     0,    10,     0,    13,
     0,    14,     0,     3,     0,    41,    68,    42,     0,    41,
    68,     1,     0,    69,     0,     0,    70,     0,    69,    43,
    70,     0,    69,    70,     0,    61,    78,     0,    47,    72,
    48,     0,    47,    72,     1,     0,    73,    80,     0,    74,
     0,     0,    75,     0,    74,    75,     0,    61,    76,    44,
     0,    61,    76,     1,     0,    77,     0,    76,    43,    77,
     0,    78,     0,    78,    40,     4,     0,    78,    40,    15,
     0,     3,     0,     3,    45,    79,    46,     0,     3,    45,
    79,     1,     0,     4,     0,     0,    81,     0,     0,    82,
     0,    81,    82,     0,    81,    75,     0,    71,     0,    83,
     0,    85,     0,    86,     0,    87,     0,    84,    44,     0,
    88,     1,     0,    88,     0,     0,     7,    41,    88,    42,
    82,     0,     7,    41,    88,    42,    82,    55,    82,     0,
    11,    41,    88,    42,    82,     0,     9,    84,    44,     0,
    89,     0,    34,     0,     0,    35,     0,     0,    36,     0,
     0,    37,     0,     0,    38,     0,     0,    41,    94,    42,
     0,    41,    94,     1,     0,    90,     0,    96,    40,    89,
     0,    96,    19,    89,     0,    96,    20,    89,     0,    96,
    21,    89,     0,    96,    22,    89,     0,    96,    23,    89,
     0,    79,    40,    89,     0,    91,     0,    90,    24,    91,
     0,    92,     0,    91,    25,    92,     0,    93,     0,    92,
    26,    93,     0,    92,    27,    93,     0,    94,     0,    93,
    28,    94,     0,    93,    29,    94,     0,    93,    30,    94,
     0,    93,    31,    94,     0,    95,     0,    94,    34,    95,
     0,    94,    35,    95,     0,    96,     0,    95,    36,    96,
     0,    95,    37,    96,     0,    95,    38,    96,     0,    97,
     0,    35,    96,     0,    39,    96,     0,    32,    96,     0,
    33,    96,     0,   101,     0,    97,    45,    88,    46,     0,
    97,    41,    98,    42,     0,    97,    32,     0,    97,    33,
     0,    97,    45,    88,     1,     0,    99,     0,     0,   100,
     0,    89,     0,   100,    43,    89,     0,     3,     0,     4,
     0,    41,    88,    42,     0
};

#endif

#if YYDEBUG != 0
static const short yyrline[] = { 0,
    32,    34,    35,    37,    38,    39,    40,    46,    47,    48,
    55,    56,    62,    64,    65,    67,    68,    70,    72,    73,
    74,    75,    77,   120,   121,   127,   128,   130,   131,   132,
   138,   140,   141,   147,   149,   150,   152,   153,   155,   163,
   174,   175,   177,   178,   179,   181,   194,   207,   213,   214,
   216,   217,   219,   220,   221,   223,   224,   225,   226,   227,
   229,   230,   236,   237,   239,   240,   242,   244,   246,   248,
   249,   250,   251,   252,   254,   255,   260,   261,   262,   263,
   264,   265,   266,   267,   273,   274,   276,   277,   279,   280,
   281,   283,   284,   285,   286,   287,   289,   290,   291,   293,
   294,   295,   296,   298,   299,   300,   301,   302,   304,   305,
   306,   307,   308,   309,   316,   317,   319,   321,   322,   324,
   329,   330
};

static const char * const yytname[] = {   "$","error","$undefined.","TIDEN",
"TNUMBER","TCONST","ELSE","TIF","TINT","TRETURN","TVOID","TWHILE","TEIF","TFLOAT",
"TCHAR","TSTRING","TOCTA","THEXA","TREAL","TADDASSIGN","TSUBASSIGN","TMULASSIGN",
"TDIVASSIGN","TMODASSIGN","TOR","TAND","TEQUAL","TNOTEQU","TGREAT","TLESS","TGREATE",
"TLESSE","TINC","TDEC","TPLUS","TMINUS","TMULTIPLY","TDIVIDE","TMOD","TNOT",
"TASSIGN","TLPAREN","TRPAREN","TCOMMA","TSEMICOLON","TLBRACKET","TRBRACKET",
"TLBRACE","TRBRACE","TNEWLINE","TERROR","TBLANK","TTAB","TEOF","LOWER_THEN_ELSE",
"TELSE","mini_c","translation_unit","external_dcl","function_def","function_header",
"dcl_spec","dcl_specifiers","dcl_specifier","type_qualifier","type_specifier",
"function_name","formal_param","opt_formal_param","formal_param_list","param_dcl",
"compound_st","compound","opt_dcl_list","declaration_list","declaration","init_dcl_list",
"init_declarator","declarator","opt_number","opt_stat_list","statement_list",
"statement","expression_st","opt_expression","if_st","while_st","return_st",
"expression","assignment_exp","logical_or_exp","logical_and_exp","equality_exp",
"relational_exp","addtive_exp","multiplicative_exp","unary_exp","postfix_exp",
"opt_actual_param","actual_param","actual_param_list","primary_exp","actual_param_list"
};
#endif

static const short yyr1[] = {     0,
    56,    57,    57,    58,    58,    58,    58,    59,    59,    59,
    60,    60,    61,    62,    62,    63,    63,    64,    65,    65,
    65,    65,    66,    67,    67,    68,    68,    69,    69,    69,
    70,    71,    71,    72,    73,    73,    74,    74,    75,    75,
    76,    76,    77,    77,    77,    78,    78,    78,    79,    79,
    80,    80,    81,    81,    81,    82,    82,    82,    82,    82,
    83,    83,    84,    84,    85,    85,    86,    87,    88,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    89,    89,    89,    89,
    89,    89,    89,    89,    90,    90,    91,    91,    92,    92,
    92,    93,    93,    93,    93,    93,    94,    94,    94,    95,
    95,    95,    95,    96,    96,    96,    96,    96,    97,    97,
    97,    97,    97,    97,    98,    98,    99,   100,   100,   101,
   101,   101
};

static const short yyr2[] = {     0,
     1,     1,     2,     1,     1,     2,     2,     2,     2,     2,
     3,     2,     1,     1,     2,     1,     1,     1,     1,     1,
     1,     1,     1,     3,     3,     1,     0,     1,     3,     2,
     2,     3,     3,     2,     1,     0,     1,     2,     3,     3,
     1,     3,     1,     3,     3,     1,     4,     4,     1,     0,
     1,     0,     1,     2,     2,     1,     1,     1,     1,     1,
     2,     2,     1,     0,     5,     7,     5,     3,     1,     2,
     2,     2,     2,     2,     3,     3,     1,     3,     3,     3,
     3,     3,     3,     3,     1,     3,     1,     3,     1,     3,
     3,     1,     3,     3,     3,     3,     1,     3,     3,     1,
     3,     3,     3,     1,     2,     2,     2,     2,     1,     4,
     4,     2,     2,     4,     1,     0,     1,     1,     3,     1,
     1,     3
};

static const short yydefact[] = {     0,
     0,    18,    19,    20,    21,    22,     1,     2,     4,     0,
     0,    13,    14,    16,    17,     5,     7,     6,     3,    10,
     9,    36,     8,    46,    27,     0,    12,     0,    41,    43,
    15,     0,     0,    52,    35,    37,    50,     0,     0,    26,
    28,    11,    40,     0,    39,     0,    46,    33,    32,   120,
   121,     0,    50,     0,     0,     0,     0,     0,    50,    56,
     0,    34,    51,    53,    57,     0,    58,    59,    60,     0,
    69,    77,    85,    87,    89,    92,    97,   100,   104,   109,
    38,    49,     0,    31,    25,    24,     0,    30,    42,    44,
    45,    50,     0,    63,    50,   121,   107,   108,   105,   106,
     0,    50,    55,    54,    61,    62,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,    50,
    50,    50,    50,    50,    50,   112,   113,    50,    50,    48,
    47,    29,     0,    68,     0,   122,    84,    86,   100,    88,
    90,    91,    93,    94,    95,    96,    98,    99,   101,   102,
   103,    79,    80,    81,    82,    83,    78,   118,     0,   115,
   117,     0,    50,    50,   111,    50,   114,   110,    65,    67,
   119,    50,    66,     0,     0,     0
};

static const short yydefgoto[] = {   174,
     7,     8,     9,    10,    32,    12,    13,    14,    15,    26,
    27,    39,    40,    41,    60,    33,    34,    35,    16,    28,
    29,    30,    61,    62,    63,    64,    65,    66,    67,    68,
    69,    70,    71,    72,    73,    74,    75,    76,    77,    78,
    79,   159,   160,   161,    80
};

static const short yypact[] = {   217,
    11,-32768,-32768,-32768,-32768,-32768,   217,-32768,-32768,    26,
    35,    38,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,    38,-32768,   -27,    38,   -20,-32768,    10,-32768,   -17,
-32768,    22,    21,    95,    38,-32768,    40,    22,    39,   186,
-32768,-32768,-32768,    22,-32768,     9,    -6,-32768,-32768,-32768,
     7,    31,   115,    42,   154,   154,   154,   154,   173,-32768,
    54,-32768,    82,-32768,-32768,     6,-32768,-32768,-32768,    33,
-32768,    51,    53,    -7,   204,    76,   -21,   196,    75,-32768,
-32768,-32768,    34,-32768,-32768,-32768,    38,-32768,-32768,-32768,
-32768,   173,    59,-32768,   173,-32768,-32768,-32768,-32768,-32768,
    55,   173,-32768,-32768,-32768,-32768,   154,   154,   154,   154,
   154,   154,   154,   154,   154,   154,   154,   154,   154,   173,
   173,   173,   173,   173,   173,-32768,-32768,   129,   173,-32768,
-32768,-32768,    63,-32768,    89,-32768,-32768,    53,-32768,    -7,
   204,   204,    76,    76,    76,    76,   -21,   -21,-32768,-32768,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,    98,-32768,
    70,    36,   134,   134,-32768,   173,-32768,-32768,    91,-32768,
-32768,   134,-32768,   144,   149,-32768
};

static const short yypgoto[] = {-32768,
-32768,   148,-32768,-32768,     1,-32768,   139,-32768,-32768,-32768,
   137,-32768,-32768,   -38,   150,-32768,-32768,-32768,    49,-32768,
   121,   136,   135,-32768,-32768,   -63,-32768,   126,-32768,-32768,
-32768,   -50,   -92,-32768,    73,    80,    15,    71,    37,   -51,
-32768,-32768,-32768,-32768,-32768
};


#define	YYLAST		236


static const short yytable[] = {   104,
    11,    88,    94,    97,    98,    99,   100,    11,   101,   137,
    43,    17,    90,   -23,   117,   118,   119,    37,   109,   110,
    25,    48,    46,    91,    47,    38,    20,   152,   153,   154,
   155,   156,   157,   106,   130,   158,   167,    24,    37,    85,
    38,   133,     2,    82,   135,     3,   -49,     4,   132,   105,
     5,     6,    44,    45,    18,   139,   139,   139,   139,   139,
   139,   139,   139,   139,   139,   149,   150,   151,    49,    21,
    36,    92,    22,   171,   107,    25,   -63,   108,   162,   131,
    86,   168,    95,    81,    50,    51,     2,    38,    52,     3,
    53,     4,    54,   102,     5,     6,   136,    50,    51,   169,
   170,    52,   134,    53,   163,    54,   126,   127,   173,   115,
   116,   103,   166,    55,    56,   128,    57,    50,    51,   129,
    58,   -50,    59,   141,   142,   -64,    55,    56,    22,    57,
   164,    50,    51,    58,   -50,    59,    50,    51,   -64,   165,
    52,    22,    53,   175,    54,   172,    55,    56,   176,    57,
    31,   147,   148,    58,    19,    59,    50,    96,   -64,    23,
    55,    56,    42,    57,    89,    55,    56,    58,    57,    59,
  -116,    83,    58,    84,    59,    50,    51,   -64,    93,   138,
    22,   143,   144,   145,   146,    55,    56,   140,    57,     0,
     2,     0,    58,     3,    59,     4,     0,     0,     5,     6,
     0,     0,     0,     0,    55,    56,     0,    57,     0,     0,
     0,    58,     0,    59,   120,   121,   122,   123,   124,     1,
     0,     2,     0,     0,     3,     0,     4,     0,    87,     5,
     6,   111,   112,   113,   114,   125
};

static const short yycheck[] = {    63,
     0,    40,    53,    55,    56,    57,    58,     7,    59,   102,
     1,     1,     4,    41,    36,    37,    38,    45,    26,    27,
    41,     1,    40,    15,     3,    25,     1,   120,   121,   122,
   123,   124,   125,     1,     1,   128,     1,     3,    45,     1,
    40,    92,     5,     4,    95,     8,    40,    10,    87,    44,
    13,    14,    43,    44,    44,   107,   108,   109,   110,   111,
   112,   113,   114,   115,   116,   117,   118,   119,    48,    44,
    22,    41,    47,   166,    24,    41,    44,    25,   129,    46,
    42,    46,    41,    35,     3,     4,     5,    87,     7,     8,
     9,    10,    11,    40,    13,    14,    42,     3,     4,   163,
   164,     7,    44,     9,    42,    11,    32,    33,   172,    34,
    35,    63,    43,    32,    33,    41,    35,     3,     4,    45,
    39,    40,    41,   109,   110,    44,    32,    33,    47,    35,
    42,     3,     4,    39,    40,    41,     3,     4,    44,    42,
     7,    47,     9,     0,    11,    55,    32,    33,     0,    35,
    12,   115,   116,    39,     7,    41,     3,     4,    44,    10,
    32,    33,    26,    35,    44,    32,    33,    39,    35,    41,
    42,    37,    39,    38,    41,     3,     4,    44,    53,   107,
    47,   111,   112,   113,   114,    32,    33,   108,    35,    -1,
     5,    -1,    39,     8,    41,    10,    -1,    -1,    13,    14,
    -1,    -1,    -1,    -1,    32,    33,    -1,    35,    -1,    -1,
    -1,    39,    -1,    41,    19,    20,    21,    22,    23,     3,
    -1,     5,    -1,    -1,     8,    -1,    10,    -1,    43,    13,
    14,    28,    29,    30,    31,    40
};
/* -*-C-*-  Note some compilers choke on comments on `#line' lines.  */
#line 3 "bison.simple"

/* Skeleton output parser for bison,
   Copyright (C) 1984, 1989, 1990 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.  */

/* As a special exception, when this file is copied by Bison into a
   Bison output file, you may use that output file without restriction.
   This special exception was added by the Free Software Foundation
   in version 1.24 of Bison.  */

#ifndef alloca
#ifdef __GNUC__
#define alloca __builtin_alloca
#else /* not GNU C.  */
#if (!defined (__STDC__) && defined (sparc)) || defined (__sparc__) || defined (__sparc) || defined (__sgi)
#include <alloca.h>
#else /* not sparc */
#if defined (MSDOS) && !defined (__TURBOC__)
#include <malloc.h>
#else /* not MSDOS, or __TURBOC__ */
#if defined(_AIX)
#include <malloc.h>
 #pragma alloca
#else /* not MSDOS, __TURBOC__, or _AIX */
#ifdef __hpux
#ifdef __cplusplus
extern "C" {
void *alloca (unsigned int);
};
#else /* not __cplusplus */
void *alloca ();
#endif /* not __cplusplus */
#endif /* __hpux */
#endif /* not _AIX */
#endif /* not MSDOS, or __TURBOC__ */
#endif /* not sparc.  */
#endif /* not GNU C.  */
#endif /* alloca not defined.  */

/* This is the parser code that is written into each bison parser
  when the %semantic_parser declaration is not specified in the grammar.
  It was written by Richard Stallman by simplifying the hairy parser
  used when %semantic_parser is specified.  */

/* Note: there must be only one dollar sign in this file.
   It is replaced by the list of actions, each action
   as one case of the switch.  */

#define yyerrok		(yyerrstatus = 0)
#define yyclearin	(yychar = YYEMPTY)
#define YYEMPTY		-2
#define YYEOF		0
#define YYACCEPT	return(0)
#define YYABORT 	return(1)
#define YYERROR		goto yyerrlab1
/* Like YYERROR except do call yyerror.
   This remains here temporarily to ease the
   transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  */
#define YYFAIL		goto yyerrlab
#define YYRECOVERING()  (!!yyerrstatus)
#define YYBACKUP(token, value) \
do								\
  if (yychar == YYEMPTY && yylen == 1)				\
    { yychar = (token), yylval = (value);			\
      yychar1 = YYTRANSLATE (yychar);				\
      YYPOPSTACK;						\
      goto yybackup;						\
    }								\
  else								\
    { yyerror ("syntax error: cannot back up"); YYERROR; }	\
while (0)

#define YYTERROR	1
#define YYERRCODE	256

#ifndef YYPURE
#define YYLEX		yylex()
#endif

#ifdef YYPURE
#ifdef YYLSP_NEEDED
#ifdef YYLEX_PARAM
#define YYLEX		yylex(&yylval, &yylloc, YYLEX_PARAM)
#else
#define YYLEX		yylex(&yylval, &yylloc)
#endif
#else /* not YYLSP_NEEDED */
#ifdef YYLEX_PARAM
#define YYLEX		yylex(&yylval, YYLEX_PARAM)
#else
#define YYLEX		yylex(&yylval)
#endif
#endif /* not YYLSP_NEEDED */
#endif

/* If nonreentrant, generate the variables here */

#ifndef YYPURE

int	yychar;			/*  the lookahead symbol		*/
YYSTYPE	yylval;			/*  the semantic value of the		*/
				/*  lookahead symbol			*/

#ifdef YYLSP_NEEDED
YYLTYPE yylloc;			/*  location data for the lookahead	*/
				/*  symbol				*/
#endif

int yynerrs;			/*  number of parse errors so far       */
#endif  /* not YYPURE */

#if YYDEBUG != 0
int yydebug;			/*  nonzero means print parse trace	*/
/* Since this is uninitialized, it does not stop multiple parsers
   from coexisting.  */
#endif

/*  YYINITDEPTH indicates the initial size of the parser's stacks	*/

#ifndef	YYINITDEPTH
#define YYINITDEPTH 200
#endif

/*  YYMAXDEPTH is the maximum size the stacks can grow to
    (effective only if the built-in stack extension method is used).  */

#if YYMAXDEPTH == 0
#undef YYMAXDEPTH
#endif

#ifndef YYMAXDEPTH
#define YYMAXDEPTH 10000
#endif

/* Prevent warning if -Wstrict-prototypes.  */
#ifdef __GNUC__
int yyparse (void);
#endif

#if __GNUC__ > 1		/* GNU C and GNU C++ define this.  */
#define __yy_memcpy(FROM,TO,COUNT)	__builtin_memcpy(TO,FROM,COUNT)
#else				/* not GNU C or C++ */
#ifndef __cplusplus

/* This is the most reliable way to avoid incompatibilities
   in available built-in functions on various systems.  */
static void
__yy_memcpy (from, to, count)
     char *from;
     char *to;
     int count;
{
  register char *f = from;
  register char *t = to;
  register int i = count;

  while (i-- > 0)
    *t++ = *f++;
}

#else /* __cplusplus */

/* This is the most reliable way to avoid incompatibilities
   in available built-in functions on various systems.  */
static void
__yy_memcpy (char *from, char *to, int count)
{
  register char *f = from;
  register char *t = to;
  register int i = count;

  while (i-- > 0)
    *t++ = *f++;
}

#endif
#endif

#line 192 "bison.simple"

/* The user can define YYPARSE_PARAM as the name of an argument to be passed
   into yyparse.  The argument should have type void *.
   It should actually point to an object.
   Grammar actions can access the variable by casting it
   to the proper pointer type.  */

#ifdef YYPARSE_PARAM
#define YYPARSE_PARAM_DECL void *YYPARSE_PARAM;
#else
#define YYPARSE_PARAM
#define YYPARSE_PARAM_DECL
#endif

int
yyparse(YYPARSE_PARAM)
     YYPARSE_PARAM_DECL
{
  register int yystate;
  register int yyn;
  register short *yyssp;
  register YYSTYPE *yyvsp;
  int yyerrstatus;	/*  number of tokens to shift before error messages enabled */
  int yychar1 = 0;		/*  lookahead token as an internal (translated) token number */

  short	yyssa[YYINITDEPTH];	/*  the state stack			*/
  YYSTYPE yyvsa[YYINITDEPTH];	/*  the semantic value stack		*/

  short *yyss = yyssa;		/*  refer to the stacks thru separate pointers */
  YYSTYPE *yyvs = yyvsa;	/*  to allow yyoverflow to reallocate them elsewhere */

#ifdef YYLSP_NEEDED
  YYLTYPE yylsa[YYINITDEPTH];	/*  the location stack			*/
  YYLTYPE *yyls = yylsa;
  YYLTYPE *yylsp;

#define YYPOPSTACK   (yyvsp--, yyssp--, yylsp--)
#else
#define YYPOPSTACK   (yyvsp--, yyssp--)
#endif

  int yystacksize = YYINITDEPTH;

#ifdef YYPURE
  int yychar;
  YYSTYPE yylval;
  int yynerrs;
#ifdef YYLSP_NEEDED
  YYLTYPE yylloc;
#endif
#endif

  YYSTYPE yyval;		/*  the variable used to return		*/
				/*  semantic values from the action	*/
				/*  routines				*/

  int yylen;

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Starting parse\n");
#endif

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY;		/* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.
     The wasted elements are never initialized.  */

  yyssp = yyss - 1;
  yyvsp = yyvs;
#ifdef YYLSP_NEEDED
  yylsp = yyls;
#endif

/* Push a new state, which is found in  yystate  .  */
/* In all cases, when you get here, the value and location stacks
   have just been pushed. so pushing a state here evens the stacks.  */
yynewstate:

  *++yyssp = yystate;

  if (yyssp >= yyss + yystacksize - 1)
    {
      /* Give user a chance to reallocate the stack */
      /* Use copies of these so that the &'s don't force the real ones into memory. */
      YYSTYPE *yyvs1 = yyvs;
      short *yyss1 = yyss;
#ifdef YYLSP_NEEDED
      YYLTYPE *yyls1 = yyls;
#endif

      /* Get the current used size of the three stacks, in elements.  */
      int size = yyssp - yyss + 1;

#ifdef yyoverflow
      /* Each stack pointer address is followed by the size of
	 the data in use in that stack, in bytes.  */
#ifdef YYLSP_NEEDED
      /* This used to be a conditional around just the two extra args,
	 but that might be undefined if yyoverflow is a macro.  */
      yyoverflow("parser stack overflow",
		 &yyss1, size * sizeof (*yyssp),
		 &yyvs1, size * sizeof (*yyvsp),
		 &yyls1, size * sizeof (*yylsp),
		 &yystacksize);
#else
      yyoverflow("parser stack overflow",
		 &yyss1, size * sizeof (*yyssp),
		 &yyvs1, size * sizeof (*yyvsp),
		 &yystacksize);
#endif

      yyss = yyss1; yyvs = yyvs1;
#ifdef YYLSP_NEEDED
      yyls = yyls1;
#endif
#else /* no yyoverflow */
      /* Extend the stack our own way.  */
      if (yystacksize >= YYMAXDEPTH)
	{
	  yyerror("parser stack overflow");
	  return 2;
	}
      yystacksize *= 2;
      if (yystacksize > YYMAXDEPTH)
	yystacksize = YYMAXDEPTH;
      yyss = (short *) alloca (yystacksize * sizeof (*yyssp));
      __yy_memcpy ((char *)yyss1, (char *)yyss, size * sizeof (*yyssp));
      yyvs = (YYSTYPE *) alloca (yystacksize * sizeof (*yyvsp));
      __yy_memcpy ((char *)yyvs1, (char *)yyvs, size * sizeof (*yyvsp));
#ifdef YYLSP_NEEDED
      yyls = (YYLTYPE *) alloca (yystacksize * sizeof (*yylsp));
      __yy_memcpy ((char *)yyls1, (char *)yyls, size * sizeof (*yylsp));
#endif
#endif /* no yyoverflow */

      yyssp = yyss + size - 1;
      yyvsp = yyvs + size - 1;
#ifdef YYLSP_NEEDED
      yylsp = yyls + size - 1;
#endif

#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Stack size increased to %d\n", yystacksize);
#endif

      if (yyssp >= yyss + yystacksize - 1)
	YYABORT;
    }

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Entering state %d\n", yystate);
#endif

  goto yybackup;
 yybackup:

/* Do appropriate processing given the current state.  */
/* Read a lookahead token if we need one and don't already have one.  */
/* yyresume: */

  /* First try to decide what to do without reference to lookahead token.  */

  yyn = yypact[yystate];
  if (yyn == YYFLAG)
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* yychar is either YYEMPTY or YYEOF
     or a valid token in external form.  */

  if (yychar == YYEMPTY)
    {
#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Reading a token: ");
#endif
      yychar = YYLEX;
    }

  /* Convert token to internal form (in yychar1) for indexing tables with */

  if (yychar <= 0)		/* This means end of input. */
    {
      yychar1 = 0;
      yychar = YYEOF;		/* Don't call YYLEX any more */

#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Now at end of input.\n");
#endif
    }
  else
    {
      yychar1 = YYTRANSLATE(yychar);

#if YYDEBUG != 0
      if (yydebug)
	{
	  fprintf (stderr, "Next token is %d (%s", yychar, yytname[yychar1]);
	  /* Give the individual parser a way to print the precise meaning
	     of a token, for further debugging info.  */
#ifdef YYPRINT
	  YYPRINT (stderr, yychar, yylval);
#endif
	  fprintf (stderr, ")\n");
	}
#endif
    }

  yyn += yychar1;
  if (yyn < 0 || yyn > YYLAST || yycheck[yyn] != yychar1)
    goto yydefault;

  yyn = yytable[yyn];

  /* yyn is what to do for this token type in this state.
     Negative => reduce, -yyn is rule number.
     Positive => shift, yyn is new state.
       New state is final state => don't bother to shift,
       just return success.
     0, or most negative number => error.  */

  if (yyn < 0)
    {
      if (yyn == YYFLAG)
	goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }
  else if (yyn == 0)
    goto yyerrlab;

  if (yyn == YYFINAL)
    YYACCEPT;

  /* Shift the lookahead token.  */

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Shifting token %d (%s), ", yychar, yytname[yychar1]);
#endif

  /* Discard the token being shifted unless it is eof.  */
  if (yychar != YYEOF)
    yychar = YYEMPTY;

  *++yyvsp = yylval;
#ifdef YYLSP_NEEDED
  *++yylsp = yylloc;
#endif

  /* count tokens shifted since error; after three, turn off error status.  */
  if (yyerrstatus) yyerrstatus--;

  yystate = yyn;
  goto yynewstate;

/* Do the default action for the current state.  */
yydefault:

  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;

/* Do a reduction.  yyn is the number of a rule to reduce with.  */
yyreduce:
  yylen = yyr2[yyn];
  if (yylen > 0)
    yyval = yyvsp[1-yylen]; /* implement default value of the action */

#if YYDEBUG != 0
  if (yydebug)
    {
      int i;

      fprintf (stderr, "Reducing via rule %d (line %d), ",
	       yyn, yyrline[yyn]);

      /* Print the symbols being reduced, and their result.  */
      for (i = yyprhs[yyn]; yyrhs[i] > 0; i++)
	fprintf (stderr, "%s ", yytname[yyrhs[i]]);
      fprintf (stderr, " -> %s\n", yytname[yyr1[yyn]]);
    }
#endif


  switch (yyn) {

case 7:
#line 41 "parser.y"
{
			yyerrok;
			printError(wrong_st);
		;
    break;}
case 10:
#line 49 "parser.y"
{
			look_tmp->type = 0;
			yyerrok;
			printError(wrong_funcdef);
		;
    break;}
case 12:
#line 57 "parser.y"
{
					yyerrok;
					printError(nofuncname);
				;
    break;}
case 19:
#line 72 "parser.y"
{type_int=1;;
    break;}
case 20:
#line 73 "parser.y"
{type_void=1;;
    break;}
case 21:
#line 74 "parser.y"
{type_float=1;;
    break;}
case 22:
#line 75 "parser.y"
{type_char=1;;
    break;}
case 23:
#line 78 "parser.y"
{
			if(look_id->type==0 || look_id->type==5)
			{
				if(type_int == 1)
				{
					look_id->type=4;
					type_int = 0;
					type_void = 0;
					type_float = 0;
					type_char = 0;
					look_tmp = look_id;
				}
				else if(type_void == 1)
				{
					look_id->type=6;
					type_int = 0;
					type_void = 0;
					type_float = 0;
					type_char = 0;
					look_tmp = look_id;
				}
				else if(type_float == 1)
				{
					look_id->type=7;
					type_int = 0;
					type_void = 0;
					type_float = 0;
					type_char = 0;
					look_tmp = look_id;
				}
				else if(type_char == 1)
				{
					look_id->type=8;
					type_int = 0;
					type_void = 0;
					type_float = 0;
					type_char = 0;
					look_tmp = look_id;
				}
			 }
		;
    break;}
case 25:
#line 122 "parser.y"
{
					yyerrok;
					printError(noparen);
				;
    break;}
case 30:
#line 133 "parser.y"
{
			yyerrok;
			printError(nocomma);
		;
    break;}
case 33:
#line 142 "parser.y"
{
			yyerrok;
			printError(nobrace);
		;
    break;}
case 39:
#line 156 "parser.y"
{
			type_int = 0;
			type_void = 0;
			type_float = 0;
			type_float = 0;
			type_char = 0;
		;
    break;}
case 40:
#line 164 "parser.y"
{
			look_tmp->type = 0;
			yyerrok;
			type_int = 0;
			type_void = 0;
			type_float = 0;
			type_char = 0;
			printError(nosemi);
		;
    break;}
case 46:
#line 182 "parser.y"
{
			if(look_id->type==0)
			{
				if(type_int==1)
					look_id->type=1;
				else if(type_float==1)
					look_id->type=2;
				else if(type_char==1)
					look_id->type=9;
			}
			look_tmp = look_id;
		;
    break;}
case 47:
#line 195 "parser.y"
{
			if(look_id->type == 0)
			{
				if(type_int==1)
					look_id->type=3;
				else if(type_float==1)
					look_id->type=10;
				else if(type_char==1)
					look_id->type=11;
				look_tmp = look_id;
			}
		;
    break;}
case 48:
#line 208 "parser.y"
{
			yyerrok;
			printError(nobracket);
		;
    break;}
case 62:
#line 231 "parser.y"
{
			yyerrok;
			printError(nosemi);
		;
    break;}
case 76:
#line 256 "parser.y"
{
						yyerrok;
						printError(noparen);
					;
    break;}
case 84:
#line 268 "parser.y"
{
						yyerrok;
						printError(assignerr);
		;
    break;}
case 114:
#line 310 "parser.y"
{
			yyerrok;
			printError(nobracket);
		;
    break;}
case 120:
#line 325 "parser.y"
{
			if(look_id->type==0)
				look_id->type = 5;
		;
    break;}
}
   /* the action file gets copied in in place of this dollarsign */
#line 487 "bison.simple"

  yyvsp -= yylen;
  yyssp -= yylen;
#ifdef YYLSP_NEEDED
  yylsp -= yylen;
#endif

#if YYDEBUG != 0
  if (yydebug)
    {
      short *ssp1 = yyss - 1;
      fprintf (stderr, "state stack now");
      while (ssp1 != yyssp)
	fprintf (stderr, " %d", *++ssp1);
      fprintf (stderr, "\n");
    }
#endif

  *++yyvsp = yyval;

#ifdef YYLSP_NEEDED
  yylsp++;
  if (yylen == 0)
    {
      yylsp->first_line = yylloc.first_line;
      yylsp->first_column = yylloc.first_column;
      yylsp->last_line = (yylsp-1)->last_line;
      yylsp->last_column = (yylsp-1)->last_column;
      yylsp->text = 0;
    }
  else
    {
      yylsp->last_line = (yylsp+yylen-1)->last_line;
      yylsp->last_column = (yylsp+yylen-1)->last_column;
    }
#endif

  /* Now "shift" the result of the reduction.
     Determine what state that goes to,
     based on the state we popped back to
     and the rule number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTBASE] + *yyssp;
  if (yystate >= 0 && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTBASE];

  goto yynewstate;

yyerrlab:   /* here on detecting error */

  if (! yyerrstatus)
    /* If not already recovering from an error, report this error.  */
    {
      ++yynerrs;

#ifdef YYERROR_VERBOSE
      yyn = yypact[yystate];

      if (yyn > YYFLAG && yyn < YYLAST)
	{
	  int size = 0;
	  char *msg;
	  int x, count;

	  count = 0;
	  /* Start X at -yyn if nec to avoid negative indexes in yycheck.  */
	  for (x = (yyn < 0 ? -yyn : 0);
	       x < (sizeof(yytname) / sizeof(char *)); x++)
	    if (yycheck[x + yyn] == x)
	      size += strlen(yytname[x]) + 15, count++;
	  msg = (char *) malloc(size + 15);
	  if (msg != 0)
	    {
	      strcpy(msg, "parse error");

	      if (count < 5)
		{
		  count = 0;
		  for (x = (yyn < 0 ? -yyn : 0);
		       x < (sizeof(yytname) / sizeof(char *)); x++)
		    if (yycheck[x + yyn] == x)
		      {
			strcat(msg, count == 0 ? ", expecting `" : " or `");
			strcat(msg, yytname[x]);
			strcat(msg, "'");
			count++;
		      }
		}
	      yyerror(msg);
	      free(msg);
	    }
	  else
	    yyerror ("parse error; also virtual memory exceeded");
	}
      else
#endif /* YYERROR_VERBOSE */
	yyerror("parse error");
    }

  goto yyerrlab1;
yyerrlab1:   /* here on error raised explicitly by an action */

  if (yyerrstatus == 3)
    {
      /* if just tried and failed to reuse lookahead token after an error, discard it.  */

      /* return failure if at end of input */
      if (yychar == YYEOF)
	YYABORT;

#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Discarding token %d (%s).\n", yychar, yytname[yychar1]);
#endif

      yychar = YYEMPTY;
    }

  /* Else will try to reuse lookahead token
     after shifting the error token.  */

  yyerrstatus = 3;		/* Each real token shifted decrements this */

  goto yyerrhandle;

yyerrdefault:  /* current state does not do anything special for the error token. */

#if 0
  /* This is wrong; only states that explicitly want error tokens
     should shift them.  */
  yyn = yydefact[yystate];  /* If its default is to accept any token, ok.  Otherwise pop it.*/
  if (yyn) goto yydefault;
#endif

yyerrpop:   /* pop the current state because it cannot handle the error token */

  if (yyssp == yyss) YYABORT;
  yyvsp--;
  yystate = *--yyssp;
#ifdef YYLSP_NEEDED
  yylsp--;
#endif

#if YYDEBUG != 0
  if (yydebug)
    {
      short *ssp1 = yyss - 1;
      fprintf (stderr, "Error: state stack now");
      while (ssp1 != yyssp)
	fprintf (stderr, " %d", *++ssp1);
      fprintf (stderr, "\n");
    }
#endif

yyerrhandle:

  yyn = yypact[yystate];
  if (yyn == YYFLAG)
    goto yyerrdefault;

  yyn += YYTERROR;
  if (yyn < 0 || yyn > YYLAST || yycheck[yyn] != YYTERROR)
    goto yyerrdefault;

  yyn = yytable[yyn];
  if (yyn < 0)
    {
      if (yyn == YYFLAG)
	goto yyerrpop;
      yyn = -yyn;
      goto yyreduce;
    }
  else if (yyn == 0)
    goto yyerrpop;

  if (yyn == YYFINAL)
    YYACCEPT;

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Shifting error token, ");
#endif

  *++yyvsp = yylval;
#ifdef YYLSP_NEEDED
  *++yylsp = yylloc;
#endif

  yystate = yyn;
  goto yynewstate;
}
#line 332 "parser.y"


void line(int n)
{
	printf("\t %d \t", n);
}
